<?php
/**
 * Loads video sitemap class.
 *
 * @package All-in-One-SEO-Pack
 *
 */

if ( AIOSEOPPRO ) {
	require_once( AIOSEOP_PLUGIN_DIR . 'pro/video_sitemap.php' );
}
